package com.aapeli.settingsgui;


public interface GuiListener {

    void unitValueChanged();

    void unitButtonClicked();
}
