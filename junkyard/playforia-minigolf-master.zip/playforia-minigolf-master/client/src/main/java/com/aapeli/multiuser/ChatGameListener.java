package com.aapeli.multiuser;


public interface ChatGameListener {

    void localUserKick(String var1);

    void localUserBan(String var1);
}
