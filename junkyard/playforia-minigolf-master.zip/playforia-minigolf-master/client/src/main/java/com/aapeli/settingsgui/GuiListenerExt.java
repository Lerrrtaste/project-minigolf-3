package com.aapeli.settingsgui;

import com.aapeli.settingsgui.Unit;

public interface GuiListenerExt {

    void unitValueChanged(Unit var1);

    void unitButtonClicked(Unit var1);
}
