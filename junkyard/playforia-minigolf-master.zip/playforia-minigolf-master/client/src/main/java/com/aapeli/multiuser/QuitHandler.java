package com.aapeli.multiuser;


public interface QuitHandler {

    void userQuit();

    void userCancel();
}
