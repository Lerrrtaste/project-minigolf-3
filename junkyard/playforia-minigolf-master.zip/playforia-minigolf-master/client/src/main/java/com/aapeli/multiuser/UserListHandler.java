package com.aapeli.multiuser;


public interface UserListHandler {

    void openPlayerCard(String var1);

    void adminCommand(String var1, String var2);

    void adminCommand(String var1, String var2, String var3);
}
