package com.aapeli.settingsgui;

import com.aapeli.settingsgui.Unit;

public final class UnitSpace extends Unit {

    private int anInt3604;


    public UnitSpace(int var1) {
        super((String) null);
        this.anInt3604 = var1;
    }

    protected int method1836() {
        return this.anInt3604;
    }

    protected boolean method1837() {
        return true;
    }
}
