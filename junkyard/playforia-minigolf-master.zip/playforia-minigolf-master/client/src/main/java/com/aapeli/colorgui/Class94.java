package com.aapeli.colorgui;

import java.awt.Color;
import java.awt.Font;

class Class94 {

    protected static final String aString1574 = "Dialog";
    protected static final Font aFont1575 = new Font("Dialog", 0, 12);
    protected static final Color aColor1576 = new Color(0, 0, 0);


}
