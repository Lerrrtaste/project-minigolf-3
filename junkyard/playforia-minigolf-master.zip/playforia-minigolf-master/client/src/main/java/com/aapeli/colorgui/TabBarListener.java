package com.aapeli.colorgui;


public interface TabBarListener {

    void selectedTabChanged(int var1);
}
