package org.moparforia.editor;

/**
 * User: Johan
 * Date: 2013-07-31
 * Time: 11:14
 */
public interface IEditor {

    int getDrawMode();

}
