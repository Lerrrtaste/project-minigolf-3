package org.moparforia.server.net;

/**
 * Playforia
 * 11.6.2013
 */
public enum PacketType {
    DATA, STRING, COMMAND, NONE
}
